from fastapi.testclient import TestClient
from backend.app.main import app
client=TestClient(app)
def test_health():
    r=client.get("/health")
    assert r.status_code==200 and r.json()["status"]=="ok"
def test_auth_required():
    assert client.get("/api/voice/voices").status_code in (401,503)
