import os, uuid, secrets, shutil, tempfile, subprocess
from pathlib import Path
import httpx, edge_tts
from fastapi import FastAPI, Header, HTTPException, Depends, BackgroundTasks
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from PIL import Image, ImageDraw, ImageFont

OUT = Path(os.getenv("CV_OUTPUT_DIR", "./output")).resolve()
OUT.mkdir(parents=True, exist_ok=True)
TOKEN = os.getenv("CV_API_TOKEN", "")
JOBS = {}
app = FastAPI(title="CuriousVerse AI API", version="0.1.0")

async def auth(authorization: str | None = Header(default=None)):
    if not TOKEN: raise HTTPException(503, "Backend access token is not configured")
    got = authorization.removeprefix("Bearer ").strip() if authorization else ""
    if not secrets.compare_digest(got, TOKEN): raise HTTPException(401, "Unauthorized")

class ScriptIn(BaseModel):
    topic: str = Field(min_length=3, max_length=300)
    category: str = "Educational"
    duration_minutes: int = Field(3, ge=0, le=60)
    language: str = "English"
    scene_count: int = Field(8, ge=1, le=40)
    api_key: str = Field(min_length=10, max_length=300)
    model: str = Field("gemini-2.5-flash", pattern=r"^[A-Za-z0-9._-]{3,100}$")

class Scene(BaseModel):
    narration: str = Field(min_length=1, max_length=5000)
    visual_description: str = ""
    on_screen_text: str = ""
    duration_seconds: int = Field(8, ge=2, le=120)

class VoiceIn(BaseModel):
    text: str = Field(min_length=1, max_length=30000)
    voice: str = "en-US-AriaNeural"
    rate: str = Field("+0%", pattern=r"^[+-]([0-9]|[1-9][0-9]|100)%$")

class VideoIn(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    scenes: list[Scene] = Field(min_length=1, max_length=40)
    width: int = Field(1920, ge=640, le=1920)
    height: int = Field(1080, ge=640, le=1920)
    voice: str = "en-US-AriaNeural"
    rate: str = "+0%"

@app.get("/health")
async def health(): return {"status":"ok","service":"curiousverse-ai"}

@app.post("/api/script/generate", dependencies=[Depends(auth)])
async def script(req: ScriptIn):
    prompt = f"""Return only JSON with title, description, tags, hashtags, thumbnail_text, scenes.
Each scene: narration, visual_description, on_screen_text, duration_seconds.
Create exactly {req.scene_count} engaging, factual scenes for a {req.duration_minutes}-minute
{req.language} {req.category} YouTube video about {req.topic}. Include a strong hook."""
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{req.model}:generateContent"
    try:
        async with httpx.AsyncClient(timeout=90) as client:
            r = await client.post(url, params={"key":req.api_key},
                json={"contents":[{"parts":[{"text":prompt}]}],
                      "generationConfig":{"responseMimeType":"application/json"}})
        if r.status_code == 404: raise HTTPException(400, "Unknown Gemini model ID; check Google's supported model list")
        if r.status_code in (401,403): raise HTTPException(400, "Gemini API key rejected or not authorized")
        r.raise_for_status()
        return {"result":r.json()["candidates"][0]["content"]["parts"][0]["text"]}
    except HTTPException: raise
    except Exception as e: raise HTTPException(502, f"Gemini request failed: {type(e).__name__}")

@app.get("/api/voice/voices", dependencies=[Depends(auth)])
async def voices():
    data = await edge_tts.list_voices()
    return {"voices":[{"name":v["ShortName"],"gender":v.get("Gender"),"locale":v.get("Locale")} for v in data]}

@app.post("/api/voice/generate", dependencies=[Depends(auth)])
async def voice(req: VoiceIn):
    p = OUT / f"{uuid.uuid4().hex}.mp3"
    try:
        await edge_tts.Communicate(req.text, req.voice, rate=req.rate).save(str(p))
        return FileResponse(p, media_type="audio/mpeg", filename="narration.mp3")
    except Exception as e:
        p.unlink(missing_ok=True)
        raise HTTPException(502, f"TTS failed: {type(e).__name__}")

async def render(jid, req):
    work = Path(tempfile.mkdtemp(prefix="cv-"))
    target = OUT / f"{jid}.mp4"
    try:
        clips=[]
        for i,s in enumerate(req.scenes):
            JOBS[jid].update(progress=int(i/len(req.scenes)*75), message=f"Scene {i+1}/{len(req.scenes)}")
            im=Image.new("RGB",(req.width,req.height),(20,19,48))
            d=ImageDraw.Draw(im); f=ImageFont.load_default()
            d.multiline_text((req.width//12,req.height//3),s.on_screen_text or s.narration[:180],
                             fill="white",font=f,spacing=14)
            d.text((req.width//12,req.height-70),f"CURIOUSVERSE  •  SCENE {i+1}",fill=(165,145,255),font=f)
            still=work/f"{i}.png"; audio=work/f"{i}.mp3"; clip=work/f"{i}.mp4"
            im.save(still)
            await edge_tts.Communicate(s.narration,req.voice,rate=req.rate).save(str(audio))
            subprocess.run(["ffmpeg","-y","-loop","1","-i",str(still),"-i",str(audio),
              "-vf",f"scale={req.width}:{req.height},format=yuv420p","-c:v","libx264",
              "-tune","stillimage","-c:a","aac","-shortest",str(clip)],
              check=True,capture_output=True,timeout=240)
            clips.append(clip)
        listing=work/"concat.txt"
        listing.write_text("".join(f"file '{p.as_posix()}'\n" for p in clips))
        subprocess.run(["ffmpeg","-y","-f","concat","-safe","0","-i",str(listing),
                        "-c","copy","-movflags","+faststart",str(target)],
                       check=True,capture_output=True,timeout=300)
        JOBS[jid].update(status="completed",progress=100,message="MP4 ready",file=str(target))
    except Exception as e:
        target.unlink(missing_ok=True)
        JOBS[jid].update(status="failed",message=f"Render failed: {type(e).__name__}")
    finally: shutil.rmtree(work,ignore_errors=True)

@app.post("/api/video/create", dependencies=[Depends(auth)])
async def create(req: VideoIn, bg: BackgroundTasks):
    jid=uuid.uuid4().hex; JOBS[jid]={"status":"queued","progress":0,"message":"Queued"}
    bg.add_task(render,jid,req)
    return {"job_id":jid,"status":"queued"}

@app.get("/api/video/status/{job_id}", dependencies=[Depends(auth)])
async def status(job_id:str):
    j=JOBS.get(job_id)
    if not j: raise HTTPException(404,"Unknown job")
    return {k:v for k,v in j.items() if k!="file"}

@app.get("/api/video/download/{job_id}", dependencies=[Depends(auth)])
async def download(job_id:str):
    j=JOBS.get(job_id)
    if not j or j.get("status")!="completed": raise HTTPException(404,"Video not ready")
    p=Path(j["file"])
    if p.parent!=OUT or not p.is_file(): raise HTTPException(404,"File missing")
    return FileResponse(p,media_type="video/mp4",filename="curiousverse.mp4")

@app.post("/api/thumbnail/generate", dependencies=[Depends(auth)])
async def thumbnail(title:str, subtitle:str=""):
    im=Image.new("RGB",(1280,720),(20,19,48)); d=ImageDraw.Draw(im); f=ImageFont.load_default()
    d.rectangle((0,0,1279,719),outline=(140,100,255),width=16)
    d.multiline_text((70,280),title[:120],fill="white",font=f,spacing=18)
    d.text((70,630),subtitle[:100],fill=(170,155,255),font=f)
    p=OUT/f"{uuid.uuid4().hex}.jpg"; im.save(p,quality=92)
    return FileResponse(p,media_type="image/jpeg",filename="thumbnail.jpg")

@app.post("/api/youtube/connect", dependencies=[Depends(auth)])
async def youtube_connect(): raise HTTPException(501,"Configure Google OAuth client before connecting YouTube")

@app.post("/api/youtube/upload", dependencies=[Depends(auth)])
async def youtube_upload(): raise HTTPException(501,"YouTube upload is unavailable until OAuth and channel authorization are configured")
