# CuriousVerse AI

An Android YouTube creator-studio starter with a Kotlin/Jetpack Compose client and FastAPI media backend.

## Current features
- Tablet-friendly dark Compose interface.
- Backend health check.
- Gemini-powered script generation through the backend.
- FastAPI scaffolding for Edge TTS narration, FFmpeg MP4 rendering, render status/download, and basic thumbnail generation.
- GitHub Actions Android build workflow.

## Quick start
See [`DEVELOPMENT_STATUS.md`](DEVELOPMENT_STATUS.md) for the verified status and limitations.

### Backend
Install FFmpeg and Python 3.11+, then:

```bash
cd backend
python -m venv .venv
# activate the virtual environment
pip install -r requirements.txt
export CV_API_TOKEN='replace-with-a-long-random-secret'
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Deploy behind HTTPS before connecting from Android. In the app's Settings, enter the HTTPS base URL, the same backend token, and a Gemini API key. The app holds keys in memory only and clears them when closed.

### Android
Open `android/` in Android Studio (JDK 17, Android SDK 35), sync Gradle, and run the `app` configuration or build `:app:assembleDebug`.

## Not yet implemented
YouTube OAuth/upload, secure persisted key storage, full video-render UI, project library, and full thumbnail editor. The current project is a functional starter, not a finished production app. See `DEVELOPMENT_STATUS.md`.
