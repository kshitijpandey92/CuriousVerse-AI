# CuriousVerse AI specification
Android tablet studio: Compose UI, FastAPI backend, Gemini scripts, Edge TTS narration, FFmpeg MP4 rendering, thumbnails, and optional YouTube Data API OAuth.
Workflow: topic/settings -> editable script -> scene narration -> graphic scenes/subtitles -> MP4 -> metadata/thumbnail -> optional upload.
Distinguish generated graphics/slideshows from genuine moving footage. Use only original or properly licensed media.
Formats: 9:16, 16:9, 1:1; 720p/1080p. YouTube visibility defaults PRIVATE; public publishing requires explicit confirmation.
User keys only; never log or commit credentials. Android secure storage and HTTPS are required.
