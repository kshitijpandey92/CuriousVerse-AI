package ai.curiousverse.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Accent = Color(0xFF9B7BFF)
private val Bg = Color(0xFF10111C)
private val SurfaceDark = Color(0xFF1B1D2C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CuriousVerseApp() }
    }
}

@Composable
private fun CuriousVerseApp() {
    var page by remember { mutableStateOf("Create") }
    var backend by remember { mutableStateOf("https://") }
    var token by remember { mutableStateOf("") }
    var geminiKey by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Educational") }
    var duration by remember { mutableStateOf("3") }
    var scenes by remember { mutableStateOf("8") }
    var language by remember { mutableStateOf("English") }
    var result by remember { mutableStateOf("Connect your backend in Settings, then generate your first script.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = SurfaceDark)) {
        Row(Modifier.fillMaxSize().padding(12.dp)) {
            Column(Modifier.width(150.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("CURIOUSVERSE AI", color = Accent, style = MaterialTheme.typography.titleMedium)
                listOf("Create", "Projects", "Thumbnail", "Settings").forEach { item ->
                    NavigationDrawerItem(label = { Text(item) }, selected = page == item, onClick = { page = item })
                }
                Spacer(Modifier.weight(1f))
                Text("YouTube creator studio", style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
            }
            Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()).padding(start = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(page, style = MaterialTheme.typography.headlineMedium)
                when (page) {
                    "Create" -> {
                        Text("Turn an idea into a YouTube-ready script", color = Color.LightGray)
                        OutlinedTextField(topic, { topic = it }, label = { Text("Video topic") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(category, { category = it }, label = { Text("Category") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(duration, { duration = it.filter(Char::isDigit).take(2) }, label = { Text("Minutes") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(scenes, { scenes = it.filter(Char::isDigit).take(2) }, label = { Text("Scenes") }, modifier = Modifier.weight(1f))
                        }
                        OutlinedTextField(language, { language = it }, label = { Text("Language") }, modifier = Modifier.fillMaxWidth())
                        Button(enabled = !busy && topic.trim().length >= 3, onClick = {
                            busy = true
                            result = "Generating your script…"
                            scope.launch {
                                result = try {
                                    requestScript(backend, token, geminiKey, topic, category, duration.toIntOrNull() ?: 3, scenes.toIntOrNull()?.coerceIn(1, 40) ?: 8, language)
                                } catch (e: Exception) { "Error: ${e.message ?: "Could not reach backend"}" }
                                busy = false
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Please wait…" else "Generate AI Script") }
                        Text("Result", style = MaterialTheme.typography.titleMedium, color = Accent)
                        Surface(color = SurfaceDark, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()) {
                            Text(result, Modifier.padding(14.dp), color = Color.White)
                        }
                    }
                    "Projects" -> Text("Your generated projects will be listed here. Video rendering is provided by the connected backend.")
                    "Thumbnail" -> Text("Thumbnail generation is available through the backend API. Connect your backend in Settings.")
                    "Settings" -> {
                        Text("Backend connection", color = Accent)
                        OutlinedTextField(backend, { backend = it }, label = { Text("Backend HTTPS URL") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(token, { token = it }, label = { Text("Backend access token") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(geminiKey, { geminiKey = it }, label = { Text("Gemini API key") }, modifier = Modifier.fillMaxWidth())
                        Text("Keys are kept in memory only and are cleared when the app closes. Use HTTPS. Never share your keys.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                        Button(onClick = {
                            busy = true
                            scope.launch {
                                result = try { healthCheck(backend) } catch (e: Exception) { "Connection failed: ${e.message}" }
                                busy = false
                            }
                        }, enabled = !busy) { Text("Test backend connection") }
                        Text(result)
                    }
                }
            }
        }
    }
}

private suspend fun healthCheck(base: String): String = withContext(Dispatchers.IO) {
    val clean = base.trim().trimEnd('/')
    require(clean.startsWith("https://")) { "Use a secure HTTPS backend URL." }
    val c = (URL("$clean/health").openConnection() as HttpURLConnection)
    try { c.connectTimeout = 10000; c.readTimeout = 10000; "Backend response: ${c.responseCode} ${c.inputStream.bufferedReader().readText()}" }
    finally { c.disconnect() }
}

private suspend fun requestScript(base: String, token: String, key: String, topic: String, category: String, minutes: Int, count: Int, language: String): String = withContext(Dispatchers.IO) {
    require(base.trim().startsWith("https://")) { "Set a valid HTTPS backend URL in Settings." }
    require(token.isNotBlank()) { "Enter your backend access token in Settings." }
    require(key.length >= 10) { "Enter your Gemini API key in Settings." }
    val body = JSONObject().apply {
        put("topic", topic); put("category", category); put("duration_minutes", minutes.coerceIn(1, 60))
        put("scene_count", count.coerceIn(1, 40)); put("language", language); put("api_key", key)
    }
    val c = (URL("${base.trim().trimEnd('/')}/api/script/generate").openConnection() as HttpURLConnection)
    try {
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 120000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("Authorization", "Bearer $token")
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (c.responseCode !in 200..299) throw IllegalStateException("HTTP ${c.responseCode}: $response")
        val json = JSONObject(response)
        json.optString("result", response)
    } finally { c.disconnect() }
}
