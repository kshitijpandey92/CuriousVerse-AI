# CuriousVerse AI — development status

Updated: 2026-11-14

## Included in this starter project
- Android Kotlin + Jetpack Compose tablet-oriented studio UI.
- Create screen with topic/category/duration/language/scene count inputs.
- Settings screen for HTTPS backend URL, backend token, and Gemini key (held in memory only; not persisted).
- Android health-check and Gemini script-generation requests wired to the FastAPI backend.
- FastAPI endpoints for Gemini script generation, Edge TTS narration, FFmpeg scene rendering, job status/download, and a basic thumbnail image.
- Backend tests and an Android GitHub Actions build workflow.

## Not complete / important limitations
- No APK has been built or device-tested in this environment: Android SDK and Gradle are not installed here.
- Python syntax compilation passed, but pytest could not collect tests because runtime dependencies (starting with `edge_tts`) are not installed in this environment. Install `backend/requirements.txt` before running tests.
- YouTube OAuth and upload endpoints are placeholders (HTTP 501); Google Cloud OAuth consent/client setup and implementation are still required.
- The Android app currently wires script generation and backend health checking. Video job creation/download, project persistence, thumbnail preview/editor, secure key storage, and YouTube upload UI remain to be implemented.
- Rendering requires FFmpeg installed on the backend host. The current renderer creates narrated still-image scenes, not generated AI artwork.
- No files have been pushed to the user's GitHub repository. The GitHub integration did not permit repository writes in the previous attempt.

## Run backend locally
1. Install Python 3.11+ and FFmpeg.
2. `cd backend && python -m venv .venv`
3. Activate the virtual environment and run `pip install -r requirements.txt`.
4. Set `CV_API_TOKEN` to a long random secret and optionally `CV_OUTPUT_DIR`.
5. Run `uvicorn app.main:app --host 0.0.0.0 --port 8000`.

Use an HTTPS deployment URL in the Android app. Do not expose the backend publicly without authentication, TLS, rate limiting, and appropriate secret management.

## Android build
Open the `android` folder in Android Studio with Android SDK 35 and JDK 17, sync Gradle, then build `:app:assembleDebug`. CI is configured to build on pushes and pull requests.
